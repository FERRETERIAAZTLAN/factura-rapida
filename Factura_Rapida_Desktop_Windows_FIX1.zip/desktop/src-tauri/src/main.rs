#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::Serialize;
use std::fs::OpenOptions;
use std::io::Write;
use std::panic;
use tauri::AppHandle;

const UPDATE_ENDPOINT: &str =
    "https://github.com/FERRETERIAAZTLAN/factura-rapida/releases/latest/download/latest.json";

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct DesktopInfo {
    native: bool,
    version: String,
    updater_configured: bool,
    update_endpoint: String,
}

fn write_startup_log(message: &str) {
    let path = std::env::temp_dir().join("factura-rapida-startup.log");
    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
        let _ = writeln!(file, "{}", message);
    }
}

#[tauri::command]
fn desktop_info(app: AppHandle) -> DesktopInfo {
    DesktopInfo {
        native: true,
        version: app.package_info().version.to_string(),
        updater_configured: false,
        update_endpoint: UPDATE_ENDPOINT.to_string(),
    }
}

fn main() {
    panic::set_hook(Box::new(|info| {
        write_startup_log(&format!("PANIC: {info}"));
    }));

    write_startup_log("START 0.1.1");

    tauri::Builder::default()
        .setup(|_| {
            write_startup_log("SETUP_OK 0.1.1");
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![desktop_info])
        .run(tauri::generate_context!())
        .unwrap_or_else(|error| {
            write_startup_log(&format!("RUN_ERROR: {error}"));
        });
}
