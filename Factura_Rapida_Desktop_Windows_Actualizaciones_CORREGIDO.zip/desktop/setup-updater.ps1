$ErrorActionPreference = "Stop"
$repo = "FERRETERIAAZTLAN/factura-rapida"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
  throw "Falta Node.js. Instala Node.js LTS primero."
}

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
  Write-Host "Instalando GitHub CLI..."
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id GitHub.cli --exact --accept-source-agreements --accept-package-agreements
  } else {
    throw "Instala GitHub CLI (gh) y vuelve a ejecutar este archivo."
  }
}

gh auth status *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host "Inicia sesión en GitHub. Se abrirá el proceso de autenticación."
  gh auth login
}

npm install

$keyDir = Join-Path $env:USERPROFILE ".factura-rapida"
New-Item -ItemType Directory -Force -Path $keyDir | Out-Null
$keyPath = Join-Path $keyDir "updater.key"

if (Test-Path $keyPath) {
  throw "Ya existe una clave en $keyPath. No la reemplazaré para evitar romper futuras actualizaciones."
}

$passwordSecure = Read-Host "Crea una contraseña para proteger la clave de actualizaciones" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($passwordSecure)
try {
  $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
} finally {
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
}
if ([string]::IsNullOrWhiteSpace($password)) {
  throw "Usa una contraseña no vacía para la clave de actualizaciones."
}

npm run tauri signer generate -- -w $keyPath -p $password

$pubPath = "$keyPath.pub"
if (-not (Test-Path $pubPath)) {
  $possible = Get-ChildItem $keyDir -Filter "*.pub" | Select-Object -First 1
  if ($possible) { $pubPath = $possible.FullName }
}
if (-not (Test-Path $pubPath)) {
  throw "No pude localizar la clave pública generada."
}

$publicLines = Get-Content $pubPath | Where-Object { $_ -notmatch '^untrusted comment:' -and $_.Trim() -ne '' }
$publicKey = ($publicLines | Select-Object -Last 1).Trim()
$privateKey = Get-Content $keyPath -Raw

Write-Host "Guardando configuración segura en GitHub..."
$privateKey | gh secret set TAURI_SIGNING_PRIVATE_KEY --repo $repo
$password | gh secret set TAURI_SIGNING_PRIVATE_KEY_PASSWORD --repo $repo
gh variable set TAURI_UPDATER_PUBKEY --repo $repo --body $publicKey

Write-Host ""
Write-Host "Actualizador configurado."
Write-Host "La clave privada quedó SOLO en: $keyPath"
Write-Host "Haz una copia de seguridad privada. No la subas al repositorio ni la envíes por chat."
