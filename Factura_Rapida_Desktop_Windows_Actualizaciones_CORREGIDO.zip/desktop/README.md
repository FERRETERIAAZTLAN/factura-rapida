# Factura Rápida Desktop

Proyecto Tauri 2 para convertir Factura Rápida en una aplicación nativa de Windows.

## Lo que ya incluye

- Ventana nativa de Windows.
- Interfaz optimizada para computadora reutilizando la app web actual.
- Atajos F2, F3, F8 y Alt+1…4 ya implementados en la web.
- Barra nativa que identifica cuando se está ejecutando como aplicación Windows.
- La ventana recuerda tamaño y posición.
- Instalador NSIS `.exe`.
- Compilación automática de Windows mediante GitHub Actions.
- Canal de actualizaciones automáticas mediante GitHub Releases.
- Verificación criptográfica obligatoria de las actualizaciones.
- La clave privada de actualizaciones nunca se guarda en el código ni en el repositorio.

## Compilación normal

El workflow `Desktop Windows - Build` fabrica un instalador de prueba cada vez que cambia `index.html` o la carpeta `desktop/`.

## Actualizaciones automáticas

Tauri exige firmar las actualizaciones. Esa protección no se puede desactivar y no debe desactivarse.

Una sola vez, desde una PC Windows con acceso al GitHub del proyecto:

```powershell
powershell -ExecutionPolicy Bypass -File .\desktop\setup-updater.ps1
```

El script genera la clave privada fuera del repositorio y guarda los secretos necesarios en GitHub. No pegues esa clave en chats ni la subas a archivos públicos.

Después, el workflow `Desktop Windows - Publicar versión` puede crear una versión firmada. La aplicación consulta:

`https://github.com/FERRETERIAAZTLAN/factura-rapida/releases/latest/download/latest.json`

y, si existe una versión más nueva y su firma es válida, la descarga e instala.

## Seguridad fiscal

El `.exe` es únicamente la interfaz. Las reglas de timbrado, producción, CSD, Finkok, recuperación de fallos y protección contra duplicados permanecen en el servidor. El programa de Windows no contiene CSD, contraseñas de Gmail ni credenciales del PAC.
