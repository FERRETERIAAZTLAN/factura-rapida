import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const desktop = resolve(here, "..");
const repo = resolve(desktop, "..");
const source = resolve(repo, "index.html");
const targetDir = resolve(desktop, "dist");
const target = resolve(targetDir, "index.html");

let html = await readFile(source, "utf8");
if (!html.includes("Factura Rápida")) {
  throw new Error("El index.html del repositorio no parece ser Factura Rápida.");
}

const nativeCss = `
<style id="frNativeDesktopCss">
html.fr-native-desktop body{padding-top:34px}
#frNativeBar{display:none}
html.fr-native-desktop #frNativeBar{
 display:flex;position:fixed;left:0;right:0;top:0;height:34px;z-index:15000;
 align-items:center;justify-content:space-between;gap:12px;padding:0 12px;
 background:#171b21;color:#fff;font:600 11px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
 box-shadow:0 1px 0 rgba(255,255,255,.08)
}
#frNativeBar .frNativeLeft,#frNativeBar .frNativeRight{display:flex;align-items:center;gap:9px;min-width:0}
#frNativeBar .frNativeApp{font-weight:850;letter-spacing:.02em}
#frNativeBar .frNativeStatus{color:#c8d0d8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#frNativeBar .frNativeDot{width:7px;height:7px;border-radius:50%;background:#62c77a;flex:none}
#frNativeBar .frNativeVersion{color:#aeb8c2}
@media(max-width:700px){#frNativeBar .frNativeStatus{display:none}}
</style>
<div id="frNativeBar">
 <div class="frNativeLeft"><span class="frNativeDot"></span><span class="frNativeApp">Factura Rápida · Windows</span><span id="frNativeVersion" class="frNativeVersion"></span></div>
 <div class="frNativeRight"><span id="frNativeUpdate" class="frNativeStatus">Nube conectada</span></div>
</div>
`;

const nativeJs = `
<script id="frNativeDesktopJs">
(function(){
 if(!window.__TAURI__) return;
 document.documentElement.classList.add('fr-native-desktop');
 const version=document.getElementById('frNativeVersion');
 const status=document.getElementById('frNativeUpdate');
 try{
   const invoke=window.__TAURI__.core.invoke;
   invoke('desktop_info').then(info=>{
     if(version)version.textContent='v'+(info?.version||'');
     if(status)status.textContent=info?.updaterConfigured?'Actualizaciones automáticas activas':'Actualizador preparado';
   }).catch(()=>{});
   if(window.__TAURI__.event?.listen){
     window.__TAURI__.event.listen('factura-update-state',e=>{
       const s=e?.payload||{};
       if(!status)return;
       if(s.state==='checking')status.textContent='Buscando actualización…';
       else if(s.state==='downloading')status.textContent='Actualizando a v'+(s.version||'')+'…';
       else if(s.state==='current')status.textContent='Aplicación actualizada';
       else if(s.state==='disabled')status.textContent='Actualizador preparado';
       else if(s.state==='error')status.textContent='No se pudo comprobar actualización';
     });
   }
 }catch(e){ console.warn('Tauri desktop bridge',e); }
})();
</script>
`;

if (!html.includes('id="frNativeBar"')) {
    html = html.replace("<body>", "<body>\n" + nativeCss, 1);
}
if (!html.includes('id="frNativeDesktopJs"')) {
    html = html.replace("</body>", nativeJs + "\n</body>", 1);
}

await mkdir(targetDir, { recursive: true });
await writeFile(target, html, "utf8");
console.log("Factura Rápida web sincronizada para Windows:", target);
