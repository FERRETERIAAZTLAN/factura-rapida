#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::Serialize;
use std::time::Duration;
use tauri::{AppHandle, Emitter};
use tauri_plugin_updater::UpdaterExt;

const UPDATE_ENDPOINT: &str =
    "https://github.com/FERRETERIAAZTLAN/factura-rapida/releases/latest/download/latest.json";

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct DesktopInfo {
    native: bool,
    version: String,
    updater_configured: bool,
    update_endpoint: String,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct UpdateState {
    state: String,
    version: Option<String>,
    message: Option<String>,
}

fn updater_pubkey() -> Option<&'static str> {
    option_env!("FR_UPDATER_PUBKEY")
        .map(str::trim)
        .filter(|value| !value.is_empty())
}

fn emit_update(app: &AppHandle, state: &str, version: Option<String>, message: Option<String>) {
    let _ = app.emit(
        "factura-update-state",
        UpdateState {
            state: state.to_string(),
            version,
            message,
        },
    );
}

#[tauri::command]
fn desktop_info(app: AppHandle) -> DesktopInfo {
    DesktopInfo {
        native: true,
        version: app.package_info().version.to_string(),
        updater_configured: updater_pubkey().is_some(),
        update_endpoint: UPDATE_ENDPOINT.to_string(),
    }
}

async fn automatic_update(app: AppHandle) -> Result<(), String> {
    let Some(pubkey) = updater_pubkey() else {
        emit_update(
            &app,
            "disabled",
            None,
            Some("Firma del actualizador aún no configurada".into()),
        );
        return Ok(());
    };

    let endpoint = url::Url::parse(UPDATE_ENDPOINT).map_err(|e| e.to_string())?;
    emit_update(&app, "checking", None, None);

    let updater = app
        .updater_builder()
        .pubkey(pubkey)
        .endpoints(vec![endpoint])
        .map_err(|e| e.to_string())?
        .timeout(Duration::from_secs(30))
        .build()
        .map_err(|e| e.to_string())?;

    let Some(update) = updater.check().await.map_err(|e| e.to_string())? else {
        emit_update(&app, "current", None, None);
        return Ok(());
    };

    let version = update.version.to_string();
    emit_update(&app, "downloading", Some(version.clone()), None);

    let progress_app = app.clone();
    let finished_app = app.clone();

    update
        .download_and_install(
            move |_chunk_length, _content_length| {
                let _ = progress_app.emit(
                    "factura-update-state",
                    UpdateState {
                        state: "downloading".into(),
                        version: Some(version.clone()),
                        message: None,
                    },
                );
            },
            move || {
                let _ = finished_app.emit(
                    "factura-update-state",
                    UpdateState {
                        state: "downloaded".into(),
                        version: None,
                        message: Some("Descarga terminada".into()),
                    },
                );
            },
        )
        .await
        .map_err(|e| e.to_string())?;

    emit_update(
        &app,
        "installed",
        None,
        Some("Actualización instalada".into()),
    );

    // En Windows el instalador puede cerrar la aplicación durante la instalación.
    // Si continúa ejecutándose, reiniciamos para abrir la versión nueva.
    app.restart();
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_window_state::Builder::default().build())
        .setup(|app| {
            app.handle()
                .plugin(tauri_plugin_updater::Builder::new().build())?;

            let handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                if let Err(error) = automatic_update(handle.clone()).await {
                    emit_update(
                        &handle,
                        "error",
                        None,
                        Some(error.chars().take(240).collect()),
                    );
                }
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![desktop_info])
        .run(tauri::generate_context!())
        .expect("error al ejecutar Factura Rápida");
}
