# Archivos para integrar al repositorio Factura Rápida

Este paquete conserva la estructura exacta que debe quedar en GitHub:

- `.github/workflows/` → compilación y publicación de Windows.
- `desktop/` → aplicación Tauri.

No reemplaza `index.html`; la aplicación de Windows copia automáticamente el `index.html` vigente durante cada compilación.

El conector de GitHub de esta sesión permite leer el repositorio, pero GitHub rechazó la creación de archivos nuevos con HTTP 403. Por eso se entrega esta estructura completa sin modificar la página pública actual.
