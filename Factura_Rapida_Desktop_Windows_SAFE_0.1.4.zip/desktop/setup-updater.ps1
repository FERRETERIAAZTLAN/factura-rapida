$ErrorActionPreference = "Stop"
$repo = "FERRETERIAAZTLAN/factura-rapida"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

function Refresh-Path {
  $machine = [Environment]::GetEnvironmentVariable("Path", "Machine")
  $user = [Environment]::GetEnvironmentVariable("Path", "User")
  $env:Path = "$machine;$user"
}

function Ensure-WingetPackage($command, $packageId, $label) {
  if (Get-Command $command -ErrorAction SilentlyContinue) { return }
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "Falta $label y Windows Package Manager (winget) no está disponible. Instala $label y vuelve a ejecutar este archivo."
  }
  Write-Host "Instalando $label..." -ForegroundColor Cyan
  winget install --id $packageId --exact --accept-source-agreements --accept-package-agreements
  Refresh-Path
  if (-not (Get-Command $command -ErrorAction SilentlyContinue)) {
    throw "$label se instaló, pero Windows todavía no lo detecta. Cierra esta ventana, vuelve a abrir CONFIGURAR_ACTUALIZACIONES.cmd y continúa."
  }
}

Write-Host "" 
Write-Host "FACTURA RAPIDA - CONFIGURACION DE ACTUALIZACIONES" -ForegroundColor Yellow
Write-Host "Esto se hace una sola vez. La clave privada NO se sube al repositorio." -ForegroundColor Gray
Write-Host ""

Ensure-WingetPackage "npm" "OpenJS.NodeJS.LTS" "Node.js LTS"
Ensure-WingetPackage "gh" "GitHub.cli" "GitHub CLI"

try {
  gh auth status *> $null
} catch {}
if ($LASTEXITCODE -ne 0) {
  Write-Host "Se abrirá GitHub para autorizar esta computadora." -ForegroundColor Cyan
  gh auth login --web --git-protocol https
}

Write-Host "Preparando herramientas de Tauri..." -ForegroundColor Cyan
npm install --no-audit --no-fund

$keyDir = Join-Path $env:USERPROFILE ".factura-rapida"
New-Item -ItemType Directory -Force -Path $keyDir | Out-Null
$keyPath = Join-Path $keyDir "updater.key"
$pubPath = "$keyPath.pub"

$passwordSecure = Read-Host "Escribe una contraseña para proteger la clave de actualizaciones (guárdala en un lugar seguro)" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($passwordSecure)
try {
  $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
} finally {
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
}
if ([string]::IsNullOrWhiteSpace($password)) {
  throw "La contraseña no puede estar vacía."
}

if (-not (Test-Path $keyPath)) {
  Write-Host "Creando clave criptográfica de actualizaciones..." -ForegroundColor Cyan
  npm run tauri signer generate -- -w $keyPath -p $password
} else {
  Write-Host "Ya existe una clave de actualizaciones. Se conservará la misma." -ForegroundColor Green
}

if (-not (Test-Path $pubPath)) {
  $possible = Get-ChildItem $keyDir -Filter "*.pub" | Select-Object -First 1
  if ($possible) { $pubPath = $possible.FullName }
}
if (-not (Test-Path $pubPath)) {
  throw "No pude localizar la clave pública generada."
}

$publicLines = Get-Content $pubPath | Where-Object { $_ -notmatch '^untrusted comment:' -and $_.Trim() -ne '' }
$publicKey = ($publicLines | Select-Object -Last 1).Trim()
$privateKey = Get-Content $keyPath -Raw

Write-Host "Guardando la firma de forma segura en GitHub..." -ForegroundColor Cyan
$privateKey | gh secret set TAURI_SIGNING_PRIVATE_KEY --repo $repo
$password | gh secret set TAURI_SIGNING_PRIVATE_KEY_PASSWORD --repo $repo
gh variable set TAURI_UPDATER_PUBKEY --repo $repo --body $publicKey

Write-Host ""
Write-Host "LISTO: actualizaciones firmadas configuradas." -ForegroundColor Green
Write-Host "Clave privada local: $keyPath" -ForegroundColor Gray
Write-Host "Haz una copia de seguridad privada de esa carpeta. No la subas a GitHub ni la envíes por chat." -ForegroundColor Yellow
Write-Host ""
Read-Host "Presiona Enter para cerrar"
