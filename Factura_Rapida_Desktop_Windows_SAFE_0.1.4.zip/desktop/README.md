# Factura Rápida Desktop · Tauri 2

Versión base: **0.1.2**

Esta carpeta convierte la web actual de Factura Rápida en una aplicación Windows instalable con Tauri 2, usando el mismo `index.html` y la misma base de datos en la nube.

## Actualizaciones

La versión 0.1.2 incorpora:

- Apartado **Configuración** dentro de la app Windows.
- Versión instalada y estado del canal de actualización.
- Comprobación manual y automática de nuevas versiones.
- Descarga e instalación desde GitHub Releases.
- Firma criptográfica obligatoria de actualizaciones.
- Inicialización tolerante a fallos: si el actualizador falla, Factura Rápida abre normalmente.

La clave privada de firma **no se guarda en el repositorio**. `setup-updater.ps1` la crea en `%USERPROFILE%\.factura-rapida\` y guarda únicamente lo necesario en GitHub Secrets/Variables.

## Importante

`sync-web.mjs` toma el `index.html` que esté en la raíz del repositorio en el momento del build. No reemplaza ni modifica el archivo web original; genera una copia Desktop en `desktop/dist/index.html`.
