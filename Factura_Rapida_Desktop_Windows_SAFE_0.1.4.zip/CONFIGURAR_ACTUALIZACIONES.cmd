@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0desktop\setup-updater.ps1"
if errorlevel 1 (
  echo.
  echo Ocurrio un error. Lee el mensaje de arriba y vuelve a intentarlo.
  pause
)
