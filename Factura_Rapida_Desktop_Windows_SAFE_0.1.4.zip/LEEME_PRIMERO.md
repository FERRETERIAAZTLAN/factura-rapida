# Factura Rápida Desktop 0.1.4

Hotfix de arranque: el actualizador se inicializa bajo demanda y nunca durante el inicio.
Configuración mantiene lenguaje de producto final. Finkok producción no se modifica.
